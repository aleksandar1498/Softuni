package arraycreator;
import java.lang.reflect.Array;
public class ArrayCreator<T>{
    public ArrayCreator()
    {}
    public <T> T[] create(int length,T item){
        T[] array=(T[]) new Object[length];
        for(int i=0;i<array.length;i++){
            array[i]=item;
        }
        return array;
    }
    public <T> T[] create(Class<T> c,int length,T item){
        T[] array= (T[]) Array.newInstance(c,length);
        for(int i=0;i<array.length;i++){
            array[i]=item;
        }
        return array;
    }
}