package arraycreator;
public class Main {
    public static void main(String args[]) {
        ArrayCreator<String> creator=new ArrayCreator<>();
        for(String s: creator.create(String.class,10,"alex")){
            System.out.println(s);
        }
    }
}