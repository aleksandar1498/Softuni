package library;
public class Main{
    public static void main(String [] args){
        Book bookOne=new Book("Animal",2003,"George Orwel");
        System.out.println(bookOne.getTitle());
    }
}