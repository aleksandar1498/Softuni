class Cargo{
    double weight;
    String type;
    public Cargo(double weight,String type){
        this.weight=weight;
        this.type=type;
    }
}