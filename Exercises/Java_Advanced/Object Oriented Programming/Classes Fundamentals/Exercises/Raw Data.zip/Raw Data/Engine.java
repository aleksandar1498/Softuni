class Engine{
    double speed;
    double power;
    public Engine(double speed,double power){
        this.speed=speed;
        this.power=power;
    }
}