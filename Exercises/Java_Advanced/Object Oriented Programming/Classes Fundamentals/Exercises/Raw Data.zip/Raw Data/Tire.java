class Tire{
    double pressure;
    int age;
    public Tire(double pressure, int age){
        this.pressure=pressure;
        this.age=age;
    }
}