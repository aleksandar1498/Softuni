package wildFarm.interfaces;

import wildFarm.abstracts.Food;

public interface Feedable {
    void eat(Food food);
}
