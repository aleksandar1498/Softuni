package wildFarm.interfaces;

public interface Soundable {
    String makeSound();
}
