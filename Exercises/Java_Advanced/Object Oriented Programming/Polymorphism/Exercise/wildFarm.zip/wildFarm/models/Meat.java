package wildFarm.models;

import wildFarm.abstracts.Food;

public class Meat extends Food {
    public Meat(Integer quantity) {
        super(quantity);
    }
}
