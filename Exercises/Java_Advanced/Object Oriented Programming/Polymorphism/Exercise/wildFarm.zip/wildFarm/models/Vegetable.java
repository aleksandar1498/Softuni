package wildFarm.models;

import wildFarm.abstracts.Food;

public class Vegetable extends Food {
    public Vegetable(Integer quantity) {
        super(quantity);
    }
}
