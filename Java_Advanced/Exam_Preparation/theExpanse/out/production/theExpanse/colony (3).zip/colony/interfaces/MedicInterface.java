package colony.interfaces;

public interface MedicInterface {
    String getSign();
}
