package colony.models.common;

import colony.interfaces.ColonyInterface;
import colony.models.colonists.Colonist;

import java.util.List;

public class Colony implements ColonyInterface {
    private int maxFamilyCount;
    private int maxFamilyCapacity;
    private List<Family> families;
    public Colony(int maxFamilyCount, int maxFamilyCapacity) {
        this.maxFamilyCount = maxFamilyCount;
        this.maxFamilyCapacity = maxFamilyCapacity;
    }

    @Override
    public int getMaxFamilyCount() {
        return this.maxFamilyCount;
    }

    @Override
    public int getMaxFamilyCapacity() {
        return this.maxFamilyCapacity;
    }

    @Override
    public List<Colonist> getColonistsByFamilyId(String familyId) {
        return null;
    }
}
