package interfaces;

public interface MedicInterface {
    String getSign();
}
