package interfaces;

public interface Repository {
}
