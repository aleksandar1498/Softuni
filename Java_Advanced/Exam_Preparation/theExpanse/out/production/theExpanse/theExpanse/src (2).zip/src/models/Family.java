package models;

import interfaces.FamilyInterface;

public class Family implements FamilyInterface {
    private String id;

    public Family(String id) {
        this.id = id;
    }

    @Override
    public String getId() {
        return this.id;
    }
}
