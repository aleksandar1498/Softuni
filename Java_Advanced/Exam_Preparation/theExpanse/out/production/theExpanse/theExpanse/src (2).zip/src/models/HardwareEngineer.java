package models;

public class HardwareEngineer extends Colonist {
    private static final int AGE_BONUS = 2;
    public HardwareEngineer(String id,String familyId,int talent,int age) {
        super(id,familyId,talent,age);
    }

    @Override
    public int getPotential() {
        int totPotential = this.getTalent();
        if(this.getAge() < 18){
            totPotential+=AGE_BONUS;
        }
        return totPotential;
    }
}
