public interface MedicInterface {
    String getSign();
}
