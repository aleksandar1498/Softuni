public interface FamilyInterface {
    String getId();
}
