package interfaces;

import models.Colonist;

import java.util.List;

public interface ColonyInterface {
   int getMaxFamilyCount();
   int getMaxFamilyCapacity();
   List<Colonist> getColonistsByFamilyId(String familyId);
}
