package interfaces;

public interface FamilyInterface {
    String getId();
}
