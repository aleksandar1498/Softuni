package colony.interfaces;

public interface FamilyInterface {
    String getId();
}
