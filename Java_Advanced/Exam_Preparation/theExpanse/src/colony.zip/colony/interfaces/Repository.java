package colony.interfaces;

public interface Repository {
}
