package callofduty;

import callofduty.core.Engine;

public class Main {
    public static void main(String[] args) throws NoSuchFieldException, IllegalAccessException {
      new Engine().run();
    }
}




