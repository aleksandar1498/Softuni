package callofduty.interfaces;

public interface Nameable {
    String getName();
}
