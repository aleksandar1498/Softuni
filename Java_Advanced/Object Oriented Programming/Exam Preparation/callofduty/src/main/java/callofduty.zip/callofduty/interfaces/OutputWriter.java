package callofduty.interfaces;

public interface OutputWriter {
    void print(String output);

    void println(String output);
}
