package callofduty.interfaces;

public interface Rateable {
    Double getRating();
}
