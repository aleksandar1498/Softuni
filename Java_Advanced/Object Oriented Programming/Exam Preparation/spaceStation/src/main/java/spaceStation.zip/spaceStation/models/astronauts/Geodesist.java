package spaceStation.models.astronauts;

public class Geodesist extends BaseAstronaut {
    public Geodesist(String name) {
        super(name, 50);
    }
}
