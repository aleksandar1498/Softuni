/**
 *
 */

/**
 * @author Aleksandar Stefanov
 *
 */
public class PrimeChecker {
    public boolean isPrime(final int n) {

        for (int i = 2; i <= n / 2; i++) {

            if (n % i == 0) {
                return false;
            }
        }
        return true;
    }
}
