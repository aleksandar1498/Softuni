
public class Main {

    public static void main(final String[] args) {
        final PrimeChecker checker = new PrimeChecker();
        for (int i = 0; i < 100; i++) {
            System.out.printf("%d %b%n", i, checker.isPrime(i));
        }
    }

}
