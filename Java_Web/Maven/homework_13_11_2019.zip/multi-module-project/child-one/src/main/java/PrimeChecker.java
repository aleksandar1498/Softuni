/**
 *
 */

/**
 * @author Aleksandar Stefanov
 *
 */
public class PrimeChecker {

    @SuppressWarnings("nls")
    public boolean isPrime(final int n) {
        if (n <= 0) {
            throw new IllegalArgumentException("N cannot be less then 1");
        }
        for (int i = 2; i <= n / 2; i++) {

            if (n % i == 0) {
                return false;
            }
        }
        return true;
    }
}
