
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;

class PrimeCheckerTest {
    private final PrimeChecker CHECKER = new PrimeChecker();

    @ParameterizedTest
    @ValueSource(ints = { 2, 3, 5, 7, 11, 13, 17, 19, 23, 29 })
    void testIsPrimeShouldReturnTrue(final int prime) {
        assertTrue(CHECKER.isPrime(prime));
    }

    @ParameterizedTest
    @ValueSource(ints = { 4, 6, 8, 9, 10, 12, 14, 15, 16, 18 })
    void testIsPrimeShouldReturnFalse(final int notPrime) {
        assertFalse(CHECKER.isPrime(notPrime));
    }

    @Test
    void testWithNegativeNumberShouldThrowError() {
        final IllegalArgumentException exc = assertThrows(IllegalArgumentException.class, () -> {
            CHECKER.isPrime(-1);
        });
        assertEquals("N cannot be less then 1", exc.getMessage());
    }

}
